namespace Restaurant.DTOs
{
    public class PlanRequest
    {
        public string? Plan { get; set; }
        public int UserId { get; set; }
    }
}
