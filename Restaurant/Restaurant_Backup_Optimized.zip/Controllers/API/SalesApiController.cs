﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesApiController : ControllerBase
    {
        private readonly ISalesService _salesService;

        public SalesApiController(ISalesService salesService)
        {
            _salesService = salesService;
        }

        [HttpPost("CreateSale")]
        [Authorize]
        public async Task<IActionResult> CreateSale([FromBody] Sale model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _salesService.CreateSaleAsync(model, currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllSales")]
        [Authorize]
        public async Task<IActionResult> GetAllSales()
        {
            var response = await _salesService.GetAllSalesAsync();
            return StatusCode(response.Status, response);
        }

        [HttpPost("ImportSales")]
        [Authorize]
        public async Task<IActionResult> ImportSales(IFormFile file)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _salesService.ImportSalesAsync(file, currentUserId);
            return StatusCode(response.Status, response);
        }
    }
}
