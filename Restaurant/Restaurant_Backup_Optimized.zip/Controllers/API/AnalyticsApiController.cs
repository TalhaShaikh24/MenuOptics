﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,Restaurant")]
    public class AnalyticsApiController : ControllerBase
    {
        private readonly IAnalyticsService _analyticsService;

        public AnalyticsApiController(IAnalyticsService analyticsService)
        {
            _analyticsService = analyticsService;
        }

        [HttpGet("GetAnalyticsDashboard")]
        public async Task<IActionResult> GetAnalyticsDashboard(DateTime? startDate, DateTime? endDate)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _analyticsService.GetAnalyticsDashboardAsync(currentUserId, startDate, endDate);
            return StatusCode(response.Status, response);
        }
    }
}
