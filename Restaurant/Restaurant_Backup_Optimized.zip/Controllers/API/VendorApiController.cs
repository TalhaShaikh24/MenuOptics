﻿using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class VendorApiController : ControllerBase
    {
        private readonly IVendorService _vendorService;

        public VendorApiController(IVendorService vendorService)
        {
            _vendorService = vendorService;
        }

        [HttpPost("RegisterVendor")]
        public async Task<IActionResult> RegisterVendor([FromForm] User model)
        {
            var response = await _vendorService.RegisterVendorAsync(model, model.File, Request.Scheme, Request.Host.Value);
            return StatusCode(response.Status, response);
        }
    }
}
