﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryApiController : ControllerBase
    {
        private readonly IInventoryService _inventoryService;

        public InventoryApiController(IInventoryService inventoryService)
        {
            _inventoryService = inventoryService;
        }

        [Authorize(Roles = "Vendor")]
        [HttpPost("InvoiceInventory")]
        public async Task<IActionResult> InvoiceInventory([FromBody] InvoiceInventoryRequest model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var requestId = HttpContext.Items["X-Request-Id"]?.ToString() ?? Guid.NewGuid().ToString();
            var result = await _inventoryService.InvoiceInventoryAsync(model, currentUserId, requestId);
            return StatusCode(result.Status, result);
        }

        [HttpGet("GetInventory/{id}")]
        public async Task<IActionResult> GetInventory(int id)
        {
            var response = await _inventoryService.GetInventoryAsync(id);
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllInventoryByRestaurant/{restaurantId}")]
        public async Task<IActionResult> GetAllInventoryByRestaurant(int restaurantId)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _inventoryService.GetAllInventoryByRestaurantAsync(restaurantId, currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpPost("UpdateClosingCount")]
        public async Task<IActionResult> UpdateClosingCount([FromBody] ClosingCountUpdateDto model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _inventoryService.UpdateClosingCountAsync(model, currentUserId);
            return StatusCode(response.Status, response);
        }
    }
}
