﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,Restaurant")]
    public class EventOnlyItemApiController : ControllerBase
    {
        private readonly IEventOnlyItemService _eventOnlyItemService;

        public EventOnlyItemApiController(IEventOnlyItemService eventOnlyItemService)
        {
            _eventOnlyItemService = eventOnlyItemService;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var restaurantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _eventOnlyItemService.GetAllAsync(restaurantId);
            var response = new Response { Status = 200, Data = result, ResponseMsg = "Success" };
            return StatusCode(response.Status, response);
        }

        [HttpPost("Create")]
        public async Task<IActionResult> Create([FromBody] EventOnlyItemDTO model)
        {
            var restaurantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _eventOnlyItemService.CreateAsync(model.Name, model.DefaultCost, restaurantId);
            var response = new Response { Status = 200, Data = result, ResponseMsg = "Success" };
            return StatusCode(response.Status, response);
        }
    }
}
