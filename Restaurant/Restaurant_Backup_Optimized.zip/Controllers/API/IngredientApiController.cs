﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class IngredientApiController : ControllerBase
    {
        private readonly IIngredientService _ingredientService;

        public IngredientApiController(IIngredientService ingredientService)
        {
            _ingredientService = ingredientService;
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Vendor")]
        [HttpPost("CreateIngredientByVendor")]
        public async Task<IActionResult> CreateIngredientByVendor([FromBody] VendorIngredientRequest model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var requestId = HttpContext.Items["X-Request-Id"]?.ToString() ?? Guid.NewGuid().ToString();
            var response = await _ingredientService.CreateIngredientByVendorAsync(model, currentUserId, requestId);
            return StatusCode(response.Status, response);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Vendor")]
        [HttpPut("UpdateIngredientPrices")]
        public async Task<IActionResult> UpdateIngredientPrices([FromBody] UpdateIngredientPriceRequest model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var requestId = HttpContext.Items["X-Request-Id"]?.ToString() ?? Guid.NewGuid().ToString();
            var response = await _ingredientService.UpdateIngredientPricesAsync(model, currentUserId, requestId);
            return StatusCode(response.Status, response);
        }

        [HttpPost("CreateIngredient")]
        public async Task<IActionResult> CreateIngredient([FromBody] Ingredient model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _ingredientService.CreateIngredientAsync(model, currentUserId);
            return StatusCode(result.Status, result);
        }

        [HttpPost("AddIngredientStock")]
        public async Task<IActionResult> AddIngredientStock([FromBody] Inventory model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _ingredientService.AddIngredientStockAsync(model, currentUserId);
            return StatusCode(result.Status, result);
        }

        [HttpGet("GetIngredient/{id}")]
        public async Task<IActionResult> GetIngredient(int id)
        {
            var response = await _ingredientService.GetIngredientAsync(id);
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllIngredients")]
        public async Task<IActionResult> GetAllIngredients()
        {
            var response = await _ingredientService.GetAllIngredientsAsync();
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllIngredientsByUserId")]
        public async Task<IActionResult> GetAllIngredientsByUserId()
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "1");
            var response = await _ingredientService.GetAllIngredientsByUserIdAsync(currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllIngredientsByVendorId")]
        public async Task<IActionResult> GetAllIngredientsByVendorId()
        {
            var vendorId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "1");
            var response = await _ingredientService.GetAllIngredientsByVendorIdAsync(vendorId);
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllIngredientsByUserId/{userId}")]
        public async Task<IActionResult> GetAllIngredientsByUserId(int userId)
        {
            var response = await _ingredientService.GetAllIngredientsByUserIdParamAsync(userId);
            return StatusCode(response.Status, response);
        }

        [HttpPut("UpdateIngredient")]
        public async Task<IActionResult> UpdateIngredient([FromBody] Ingredient model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _ingredientService.UpdateIngredientAsync(model, currentUserId);
            return StatusCode(response.Status, response);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Vendor")]
        [HttpPatch("PatchIngredientDetails")]
        public async Task<IActionResult> PatchIngredientDetails([FromBody] UpdateIngredientDetailsRequest model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _ingredientService.PatchIngredientDetailsAsync(model, currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpDelete("DeleteIngredientById/{id}")]
        public async Task<IActionResult> DeleteIngredientById(int id)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _ingredientService.DeleteIngredientAsync(id, currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpPut("ToggleIngredientActive/{id}")]
        public async Task<IActionResult> ToggleIngredientActive(int id)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _ingredientService.ToggleIngredientActiveAsync(id, currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetAllVendors")]
        public async Task<IActionResult> GetAllVendors()
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "1");
            var response = await _ingredientService.GetAllVendorsAsync(currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpPost("LinkVendor")]
        public async Task<IActionResult> LinkVendor([FromBody] LinkVendorRequest model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _ingredientService.LinkVendorAsync(model.VendorId ?? 0, currentUserId);
            return StatusCode(response.Status, response);
        }

        [HttpDelete("UnlinkVendor/{vendorId}")]
        public async Task<IActionResult> UnlinkVendor(int vendorId)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _ingredientService.UnlinkVendorAsync(vendorId, currentUserId);
            return StatusCode(response.Status, response);
        }
    }
}
