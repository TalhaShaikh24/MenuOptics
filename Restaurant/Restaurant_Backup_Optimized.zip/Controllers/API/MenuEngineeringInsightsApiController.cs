﻿using Microsoft.AspNetCore.Mvc;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuEngineeringInsightsApiController : ControllerBase
    {
        private readonly IMenuEngineeringInsightsService _insightsService;

        public MenuEngineeringInsightsApiController(IMenuEngineeringInsightsService insightsService)
        {
            _insightsService = insightsService;
        }

        [HttpGet("GetAllMenuEngineeringInsightsByUserId")]
        public async Task<IActionResult> GetAllMenuEngineeringInsightsByUserId(DateTime? startDate, DateTime? endDate)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _insightsService.GetAllMenuEngineeringInsightsByUserIdAsync(currentUserId, startDate, endDate);
            return StatusCode(response.Status, response);
        }
    }
}
