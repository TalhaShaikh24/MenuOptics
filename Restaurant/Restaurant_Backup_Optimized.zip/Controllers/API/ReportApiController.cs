﻿using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportApiController : ControllerBase
    {
        private readonly IReportService _reportService;

        public ReportApiController(IReportService reportService)
        {
            _reportService = reportService;
        }

        [HttpPost("CogsReport")]
        public async Task<IActionResult> CogsReport([FromBody] CogsReportRequest model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new Response { Status = 400, ResponseMsg = "Invalid input." });
            }

            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (currentUserId == 0)
            {
                return Unauthorized(new Response { Status = 401, ResponseMsg = "Unauthorized" });
            }

            var response = await _reportService.CogsReportAsync(model, currentUserId);
            return StatusCode(response.Status, response);
        }
    }
}
