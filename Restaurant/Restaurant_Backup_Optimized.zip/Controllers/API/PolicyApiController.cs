﻿using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Security.Claims;

namespace Restaurant.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class PolicyApiController : ControllerBase
    {
        private readonly IPolicyService _policyService;

        public PolicyApiController(IPolicyService policyService)
        {
            _policyService = policyService;
        }

        [HttpGet("GetAllPolicies")]
        public async Task<IActionResult> GetAllPolicies()
        {
            var response = await _policyService.GetAllPoliciesAsync();
            return StatusCode(response.Status, response);
        }

        [HttpGet("GetPolicyByType")]
        public async Task<IActionResult> GetPolicyByType(string type)
        {
            var response = await _policyService.GetPolicyByTypeAsync(type);
            return StatusCode(response.Status, response);
        }

        [HttpPost("SavePolicy")]
        public async Task<IActionResult> SavePolicy([FromBody] PolicyDTO model)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var response = await _policyService.SavePolicyAsync(model, currentUserId);
            return StatusCode(response.Status, response);
        }
    }
}
