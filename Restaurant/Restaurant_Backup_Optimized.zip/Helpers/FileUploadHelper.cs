using Microsoft.AspNetCore.Http;

namespace Restaurant.Helpers
{
    public static class FileUploadHelper
    {
        public static async Task<string> UploadFileAsync(IFormFile? file, string webRootPath, string subFolder)
        {
            if (file == null || file.Length == 0)
                return string.Empty;

            var uploadsFolder = Path.Combine(webRootPath ?? Directory.GetCurrentDirectory(), subFolder);
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var filePath = Path.Combine(uploadsFolder, fileName);

            await using var stream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(stream);

            return fileName;
        }

        public static string GenerateFileUrl(string fileName, string scheme, string host, string subFolder)
        {
            if (string.IsNullOrEmpty(fileName))
                return string.Empty;
            return $"{scheme}://{host}/{subFolder}/{fileName}";
        }
    }
}
