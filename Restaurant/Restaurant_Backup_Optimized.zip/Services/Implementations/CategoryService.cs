using Dapper;
using Restaurant.Data;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class CategoryService : ICategoryService
    {
        private readonly DapperContext _context;

        public CategoryService(DapperContext context)
        {
            _context = context;
        }

        public async Task<Response> GetAllCategoriesAsync(int restaurantId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");
                parameters.Add("@RestaurantId", restaurantId);

                var categories = await connection.QueryAsync<Category>("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Categories retrieved successfully.";
                response.Data = categories;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetCategoryAsync(int id, int restaurantId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CategoryId", id);
                parameters.Add("@RestaurantId", restaurantId);
                parameters.Add("@Action", "SELECT_BY_ID");

                var category = await connection.QuerySingleOrDefaultAsync<Category>("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (category == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Category not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Category retrieved successfully.";
                response.Data = category;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> CreateCategoryAsync(string name, string? description, int createdBy)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Name", name);
                parameters.Add("@Description", description);
                parameters.Add("@CreatedBy", createdBy);
                parameters.Add("@Action", "INSERT");

                int categoryId = await connection.ExecuteScalarAsync<int>("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Category created successfully.";
                response.Data = new { CategoryId = categoryId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> UpdateCategoryAsync(int categoryId, string name, string? description, bool isActive, int modifiedBy)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CategoryId", categoryId);
                parameters.Add("@Name", name);
                parameters.Add("@Description", description);
                parameters.Add("@ModifiedBy", modifiedBy);
                parameters.Add("@IsActive", isActive);
                parameters.Add("@Action", "UPDATE");

                await connection.ExecuteAsync("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Category updated successfully.";
                response.Data = new { CategoryId = categoryId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> ToggleCategoryActiveAsync(int id, int modifiedBy)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CategoryId", id);
                parameters.Add("@Action", "SELECT_BY_ID");

                var category = await connection.QueryFirstOrDefaultAsync<Category>("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (category == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Category not found.";
                    return response;
                }

                parameters = new DynamicParameters();
                parameters.Add("@CategoryId", id);
                parameters.Add("@IsActive", !category.IsActive);
                parameters.Add("@ModifiedBy", modifiedBy);
                parameters.Add("@Action", "TOGGLE_ACTIVE");

                await connection.ExecuteAsync("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = $"Category {(category.IsActive ? "deactivated" : "activated")} successfully.";
                response.Data = new { CategoryId = id, IsActive = !category.IsActive };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> DeleteCategoryAsync(int id, int modifiedBy)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CategoryId", id);
                parameters.Add("@ModifiedBy", modifiedBy);
                parameters.Add("@Action", "DELETE");

                await connection.ExecuteAsync("sp_CategoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Category deleted successfully.";
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
