using Dapper;
using Microsoft.AspNetCore.Http;
using OfficeOpenXml;
using Restaurant.Data;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;
using System.Text.Json;

namespace Restaurant.Services.Implementations
{
    public class SalesService : ISalesService
    {
        private readonly DapperContext _context;
        private const decimal TAX_RATE = 0.085m;

        public SalesService(DapperContext context)
        {
            _context = context;
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        public async Task<Response> CreateSaleAsync(Sale model, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var saleParameters = new DynamicParameters();
                saleParameters.Add("@UserId", currentUserId);
                saleParameters.Add("@SaleDate", model.SaleDate);
                saleParameters.Add("@EndSaleDate", model.EndSaleDate);
                saleParameters.Add("@Subtotal", model.Subtotal);
                saleParameters.Add("@Tax", model.Tax);
                saleParameters.Add("@Total", model.Total);
                saleParameters.Add("@CreatedBy", currentUserId);
                saleParameters.Add("@Action", "INSERT");

                int saleId = await connection.ExecuteScalarAsync<int>("sp_SaleCRUD", saleParameters, commandType: CommandType.StoredProcedure);

                foreach (var item in model.Items)
                {
                    var itemParameters = new DynamicParameters();
                    itemParameters.Add("@SaleId", saleId);
                    itemParameters.Add("@MenuItemId", item.MenuItemId);
                    itemParameters.Add("@Quantity", item.Quantity);
                    itemParameters.Add("@Price", item.Price);
                    itemParameters.Add("@CreatedBy", currentUserId);
                    itemParameters.Add("@UserId", currentUserId);
                    itemParameters.Add("@Action", "INSERT_ITEM");
                    await connection.ExecuteAsync("sp_SaleCRUD", itemParameters, commandType: CommandType.StoredProcedure);
                }

                var selectParameters = new DynamicParameters();
                selectParameters.Add("@SaleId", saleId);
                selectParameters.Add("@Action", "SELECT");

                var sale = await connection.QueryFirstOrDefaultAsync<Sale>("sp_SaleCRUD", selectParameters, commandType: CommandType.StoredProcedure);

                if (sale == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Sale not found after creation.";
                    return response;
                }

                var saleItems = string.IsNullOrEmpty(sale.ItemsJson)
                    ? new List<SaleItem>()
                    : JsonSerializer.Deserialize<List<SaleItem>>(sale.ItemsJson);

                response.Status = 200;
                response.ResponseMsg = "Sale created successfully.";
                response.Data = new
                {
                    sale.SaleId,
                    sale.SaleDate,
                    sale.Subtotal,
                    sale.Tax,
                    sale.Total,
                    Items = saleItems
                };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllSalesAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");

                var sales = await connection.QueryAsync<Sale>("sp_SaleCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Sales retrieved successfully.";
                response.Data = sales;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> ImportSalesAsync(IFormFile file, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                if (file == null || file.Length == 0)
                {
                    response.Status = 400;
                    response.ResponseMsg = "No file uploaded.";
                    return response;
                }

                if (!file.FileName.EndsWith(".xlsx") && !file.FileName.EndsWith(".xls"))
                {
                    response.Status = 400;
                    response.ResponseMsg = "Invalid file format. Please upload an Excel file (.xlsx or .xls).";
                    return response;
                }

                var sales = new List<Sale>();
                var currentSale = new Sale();

                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    using (var package = new ExcelPackage(stream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        int rowCount = worksheet.Dimension.Rows;

                        for (int row = 2; row <= rowCount; row++)
                        {
                            var saleDate = worksheet.Cells[row, 1].GetValue<DateTime?>();
                            var subtotal = worksheet.Cells[row, 2].GetValue<decimal?>();
                            var total = worksheet.Cells[row, 3].GetValue<decimal?>();
                            var menuItemId = worksheet.Cells[row, 4].GetValue<int?>();
                            var menuItemName = worksheet.Cells[row, 5].GetValue<string?>();
                            var quantity = worksheet.Cells[row, 6].GetValue<int?>();

                            if (!saleDate.HasValue || !subtotal.HasValue || !total.HasValue || !menuItemId.HasValue || !quantity.HasValue)
                                continue;

                            var menuItemParams = new DynamicParameters();
                            menuItemParams.Add("@MenuItemId", menuItemId);
                            menuItemParams.Add("@MenuItemName", menuItemId);
                            menuItemParams.Add("@Action", "SELECT");
                            var menuItem = await connection.QueryFirstOrDefaultAsync<Menu>("sp_MenuCRUD", menuItemParams, commandType: CommandType.StoredProcedure);

                            if (menuItem == null)
                            {
                                response.Status = 400;
                                response.ResponseMsg = $"Invalid MenuItemId {menuItemId} at row {row}.";
                                return response;
                            }

                            var price = (decimal)menuItem.SellingPrice;
                            var itemTotal = price * quantity.Value;

                            if (currentSale.SaleDate != saleDate || row == 2)
                            {
                                if (row > 2 && currentSale.Items.Any())
                                    sales.Add(currentSale);

                                currentSale = new Sale
                                {
                                    SaleDate = saleDate.Value,
                                    Subtotal = 0,
                                    Tax = 0,
                                    Total = total.Value,
                                    Items = new List<SaleItem>()
                                };
                            }

                            currentSale.Subtotal += itemTotal;
                            currentSale.Items.Add(new SaleItem
                            {
                                MenuItemId = menuItemId.Value,
                                Name = menuItem.Name,
                                Quantity = quantity.Value,
                                Price = price
                            });
                        }

                        if (currentSale.Items.Any())
                            sales.Add(currentSale);
                    }
                }

                foreach (var sale in sales)
                {
                    sale.Tax = sale.Subtotal * TAX_RATE;
                    sale.Total = sale.Subtotal + sale.Tax;

                    var saleParameters = new DynamicParameters();
                    saleParameters.Add("@UserId", currentUserId);
                    saleParameters.Add("@SaleDate", sale.SaleDate);
                    saleParameters.Add("@Subtotal", sale.Subtotal);
                    saleParameters.Add("@Tax", sale.Tax);
                    saleParameters.Add("@Total", sale.Total);
                    saleParameters.Add("@CreatedBy", currentUserId);
                    saleParameters.Add("@Action", "INSERT");

                    int saleId = await connection.ExecuteScalarAsync<int>("sp_SaleCRUD", saleParameters, commandType: CommandType.StoredProcedure);

                    foreach (var item in sale.Items)
                    {
                        var itemParameters = new DynamicParameters();
                        itemParameters.Add("@SaleId", saleId);
                        itemParameters.Add("@MenuItemId", item.MenuItemId);
                        itemParameters.Add("@MenuItemName", item.MenuItemName);
                        itemParameters.Add("@Quantity", item.Quantity);
                        itemParameters.Add("@Price", item.Price);
                        itemParameters.Add("@UserId", currentUserId);
                        itemParameters.Add("@CreatedBy", currentUserId);
                        itemParameters.Add("@Action", "INSERT_ITEM");
                        await connection.ExecuteAsync("sp_SaleCRUD", itemParameters, commandType: CommandType.StoredProcedure);
                    }
                }

                response.Status = 200;
                response.ResponseMsg = $"Successfully imported {sales.Count} sales.";
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
