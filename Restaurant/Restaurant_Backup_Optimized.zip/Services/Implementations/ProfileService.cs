using Dapper;
using Microsoft.AspNetCore.Http;
using Restaurant.Data;
using Restaurant.Helpers;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class ProfileService : IProfileService
    {
        private readonly DapperContext _context;
        private readonly IWebHostEnvironment _environment;

        public ProfileService(DapperContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public async Task<Response> GetCurrentUserAsync(int userId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", userId);
            parameters.Add("@Action", "SELECT");

            var user = await connection.QueryFirstOrDefaultAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

            if (user == null)
            {
                response.Status = 404;
                response.ResponseMsg = "User not found";
                return response;
            }

            response.Status = 200;
            response.Data = user;
            return response;
        }

        public async Task<object> UpdateProfileAsync(User model, IFormFile? file, string scheme, string host, int currentUserId)
        {
            using var connection = _context.CreateConnection();
            try
            {
                string filePathUrl = model.ProfilePic;

                if (file != null)
                {
                    var fileName = await FileUploadHelper.UploadFileAsync(file, _environment.WebRootPath, "Uploads");
                    filePathUrl = FileUploadHelper.GenerateFileUrl(fileName, scheme, host, "Uploads");
                }

                var parameters = new DynamicParameters();
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@FirstName", model.FirstName);
                parameters.Add("@LastName", model.LastName);
                parameters.Add("@Username", model.Username);
                parameters.Add("@Email", model.Email);
                parameters.Add("@Phone", model.Phone);
                parameters.Add("@ProfilePic", filePathUrl);
                parameters.Add("@Address", model.Address);
                parameters.Add("@Country", model.Country);
                parameters.Add("@State", model.State);
                parameters.Add("@City", model.City);
                parameters.Add("@Zip", model.Zip);
                parameters.Add("@Gender", model.Gender);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@Action", "UPDATE");

                var updatedUser = await connection.QueryFirstOrDefaultAsync<User>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                return new
                {
                    status = 200,
                    responseMsg = "Profile updated successfully!",
                    data = updatedUser
                };
            }
            catch (Exception ex)
            {
                return new { status = 500, responseMsg = ex.Message };
            }
        }
    }
}
