using Dapper;
using Microsoft.AspNetCore.Http;
using Restaurant.Data;
using Restaurant.Helpers;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class IngredientService : IIngredientService
    {
        private readonly DapperContext _context;
        private readonly IActivityLogService _activityLog;

        private static readonly HashSet<string> _allowedUnits = new(StringComparer.OrdinalIgnoreCase)
        {
            "BA", "BG", "BX", "CA", "CM", "CT", "DZ", "EA",
            "FL", "FT", "GA", "GM", "HR", "IN", "KG", "LB",
            "LT", "ML", "MR", "OZ", "PA", "PC", "PR", "PT",
            "RL", "TB"
        };

        public IngredientService(DapperContext context, IActivityLogService activityLog)
        {
            _context = context;
            _activityLog = activityLog;
        }

        public async Task<Response> CreateIngredientByVendorAsync(VendorIngredientRequest model, int currentUserId, string requestId)
        {
            var response = new Response();
            var payload = System.Text.Json.JsonSerializer.Serialize(model);

            if (!_allowedUnits.Contains(model.Unit?.ToLower()))
            {
                response.Status = 400;
                response.ResponseMsg = $"Invalid unit '{model.Unit}'. Allowed units: {string.Join(", ", _allowedUnits)}";
                await _activityLog.LogAsync(currentUserId, requestId, "POST /api/IngredientApi/CreateIngredientByVendor", payload,
                    System.Text.Json.JsonSerializer.Serialize(response), "Warning");
                return response;
            }

            try
            {
                using var connection = _context.CreateConnection();
                connection.Open();

                decimal basePrice = 0;
                if (model.PackSize != null && model.PackSize > 0)
                    basePrice = model.BasePrice / model.PackSize.Value;
                else if (model.Weight != null && model.Weight > 0)
                    basePrice = model.BasePrice / model.Weight.Value;
                else
                {
                    response.Status = 400;
                    response.ResponseMsg = "Either PackSize or Weight must be provided and greater than zero.";
                    await _activityLog.LogAsync(currentUserId, requestId, "POST /api/IngredientApi/CreateIngredientByVendor", payload,
                        System.Text.Json.JsonSerializer.Serialize(response), "Warning");
                    return response;
                }

                var parameters = new DynamicParameters();
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@Name", model.Name);
                parameters.Add("@Price", basePrice);
                parameters.Add("@Unit", model.Unit);
                parameters.Add("@VendorProductId", model.VendorProductId);
                parameters.Add("@CreatedBy", currentUserId);

                if (model.RestaurantPrices != null && model.RestaurantPrices.Any())
                {
                    parameters.Add("@RestaurantIds", string.Join(",", model.RestaurantPrices.Select(r => r.RestaurantId)));
                    var restaurantPricesDict = model.RestaurantPrices.ToDictionary(
                        r => r.RestaurantId.ToString(),
                        r => model.PackSize != null && model.PackSize > 0 ? r.Price / model.PackSize.Value : r.Price / model.Weight!.Value);
                    parameters.Add("@RestaurantPrices", System.Text.Json.JsonSerializer.Serialize(restaurantPricesDict));
                }

                parameters.Add("@Action", "INSERT_BY_VENDOR");

                int ingredientId = await connection.ExecuteScalarAsync<int>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Ingredient created successfully.";
                response.Data = new { IngredientId = ingredientId };

                await _activityLog.LogAsync(currentUserId, requestId, "POST /api/IngredientApi/CreateIngredientByVendor", payload,
                    System.Text.Json.JsonSerializer.Serialize(new { response.Status, response.ResponseMsg, response.Data }), "Success");
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
                await _activityLog.LogAsync(currentUserId, requestId, "POST /api/IngredientApi/CreateIngredientByVendor", payload,
                    System.Text.Json.JsonSerializer.Serialize(response), "Error");
            }
            return response;
        }

        public async Task<Response> UpdateIngredientPricesAsync(UpdateIngredientPriceRequest model, int currentUserId, string requestId)
        {
            var response = new Response();
            var payload = System.Text.Json.JsonSerializer.Serialize(model);

            try
            {
                using var connection = _context.CreateConnection();
                connection.Open();

                decimal basePrice = 0;
                if (model.PackSize != null && model.PackSize > 0)
                    basePrice = model.BasePrice / model.PackSize.Value;
                else if (model.Weight != null && model.Weight > 0)
                    basePrice = model.BasePrice / model.Weight.Value;
                else
                {
                    response.Status = 400;
                    response.ResponseMsg = "Either PackSize or Weight must be provided and greater than zero.";
                    await _activityLog.LogAsync(currentUserId, requestId, "PUT /api/IngredientApi/UpdateIngredientPrices", payload,
                        System.Text.Json.JsonSerializer.Serialize(response), "Warning");
                    return response;
                }

                var parameters = new DynamicParameters();
                parameters.Add("@IngredientId", model.IngredientId);
                parameters.Add("@Price", basePrice);
                parameters.Add("@CreatedBy", currentUserId);
                parameters.Add("@ModifiedBy", currentUserId);

                if (model.RestaurantPrices != null && model.RestaurantPrices.Any())
                {
                    var restaurantPricesDictUpd = model.RestaurantPrices.ToDictionary(
                        r => r.RestaurantId.ToString(),
                        r => model.PackSize != null && model.PackSize > 0 ? r.Price / model.PackSize.Value : r.Price / model.Weight!.Value);
                    parameters.Add("@RestaurantPrices", System.Text.Json.JsonSerializer.Serialize(restaurantPricesDictUpd));
                }

                parameters.Add("@Action", "UPDATE_PRICES");
                await connection.ExecuteAsync("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Prices updated successfully.";
                await _activityLog.LogAsync(currentUserId, requestId, "PUT /api/IngredientApi/UpdateIngredientPrices", payload,
                    System.Text.Json.JsonSerializer.Serialize(new { response.Status, response.ResponseMsg }), "Success");
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = ex.Message;
                await _activityLog.LogAsync(currentUserId, requestId, "PUT /api/IngredientApi/UpdateIngredientPrices", payload,
                    System.Text.Json.JsonSerializer.Serialize(response), "Error");
            }
            return response;
        }

        public async Task<Response> CreateIngredientAsync(Ingredient model, int currentUserId)
        {
            var response = new Response();

            if (!_allowedUnits.Contains(model.Unit?.ToLower()))
            {
                response.Status = 400;
                response.ResponseMsg = $"Invalid unit '{model.Unit}'. Allowed units: {string.Join(", ", _allowedUnits)}";
                return response;
            }

            if (string.IsNullOrEmpty(model.Stock))
            {
                response.Status = 400;
                response.ResponseMsg = "Initial Stock cannot be 0, Please enter the stock";
                return response;
            }

            try
            {
                using var connection = _context.CreateConnection();
                connection.Open();

                var parameters = new DynamicParameters();
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@Name", model.Name);
                parameters.Add("@Price", model.Price);
                parameters.Add("@Unit", model.Unit);
                parameters.Add("@UnitOfMeasure", model.UnitOfMeasure);
                parameters.Add("@CreatedBy", currentUserId);
                parameters.Add("@Action", "INSERT");

                int ingredientId = await connection.ExecuteScalarAsync<int>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                var parameters2 = new DynamicParameters();
                if (ingredientId > 0)
                {
                    parameters2.Add("@RestaurantId", currentUserId);
                    parameters2.Add("@VendorId", null);
                    parameters2.Add("@IngredientId", ingredientId);
                    parameters2.Add("@Stock", model.Stock);
                    parameters2.Add("@CreatedBy", currentUserId);
                    parameters2.Add("@Action", "INSERT");

                    int inventoryId = await connection.ExecuteScalarAsync<int>("sp_InventoryCRUD", parameters2, commandType: CommandType.StoredProcedure);

                    response.Status = 200;
                    response.ResponseMsg = "Ingredient created successfully.";
                    response.Data = new { IngredientId = ingredientId, InventoryId = inventoryId };
                }
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            return response;
        }

        public async Task<Response> AddIngredientStockAsync(Inventory model, int currentUserId)
        {
            var response = new Response();

            if (string.IsNullOrEmpty(model.Stock.ToString()))
            {
                response.Status = 400;
                response.ResponseMsg = "Initial Stock cannot be 0, Please enter the stock";
                return response;
            }

            try
            {
                using var connection = _context.CreateConnection();
                connection.Open();

                var parameters = new DynamicParameters();
                parameters.Add("@RestaurantId", currentUserId);
                parameters.Add("@VendorId", null);
                parameters.Add("@IngredientId", model.IngredientId);
                parameters.Add("@Stock", model.Stock);
                parameters.Add("@CreatedBy", currentUserId);
                parameters.Add("@Action", "INSERT");

                int inventoryId = await connection.ExecuteScalarAsync<int>("sp_InventoryCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Ingredient created successfully.";
                response.Data = new { IngredientId = model.IngredientId, InventoryId = inventoryId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            return response;
        }

        public async Task<Response> GetIngredientAsync(int id)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@IngredientId", id);
                parameters.Add("@Action", "SELECT");

                var ingredient = await connection.QueryFirstOrDefaultAsync<Ingredient>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (ingredient == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Ingredient not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Ingredient retrieved successfully.";
                response.Data = ingredient;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllIngredientsAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");

                var ingredients = await connection.QueryAsync<Ingredient>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "Ingredients retrieved successfully.";
                response.Data = ingredients;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllIngredientsByUserIdAsync(int userId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", userId);
                parameters.Add("@Action", "SELECT_ALL_BY_USERID");

                var ingredients = await connection.QueryAsync<Ingredient>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "Ingredients retrieved successfully.";
                response.Data = ingredients;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllIngredientsByVendorIdAsync(int vendorId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");
                var ingredients = (await connection.QueryAsync<Ingredient>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure))
                    .Where(i => i.VendorId == vendorId).ToList();

                if (!ingredients.Any())
                {
                    response.Status = 404;
                    response.ResponseMsg = "No ingredients found for the specified vendor.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Ingredients retrieved successfully.";
                response.Data = ingredients;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllIngredientsByUserIdParamAsync(int userId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");
                var ingredients = (await connection.QueryAsync<Ingredient>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure))
                    .Where(i => i.UserId == userId).ToList();

                if (!ingredients.Any())
                {
                    response.Status = 404;
                    response.ResponseMsg = "No ingredients found for the specified user.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Ingredients retrieved successfully.";
                response.Data = ingredients;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> UpdateIngredientAsync(Ingredient model, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                if (model.IngredientId <= 0)
                {
                    response.Status = 400;
                    response.ResponseMsg = "IngredientId is required for updating an ingredient.";
                    return response;
                }

                var parameters = new DynamicParameters();
                parameters.Add("@IngredientId", model.IngredientId);
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@Name", model.Name);
                parameters.Add("@Price", model.Price);
                parameters.Add("@Unit", model.Unit);
                parameters.Add("@UnitOfMeasure", model.UnitOfMeasure);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@IsActive", 1);
                parameters.Add("@Action", "UPDATE");

                int affectedRows = await connection.ExecuteAsync("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (affectedRows == 0)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Ingredient not found or no changes were made.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Ingredient updated successfully.";
                response.Data = new { IngredientId = model.IngredientId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> PatchIngredientDetailsAsync(UpdateIngredientDetailsRequest model, int currentUserId)
        {
            var response = new Response();

            if (model.IngredientId <= 0)
            {
                response.Status = 400;
                response.ResponseMsg = "IngredientId is required.";
                return response;
            }

            if (model.Name == null && model.Unit == null && model.IsActive == null)
            {
                response.Status = 400;
                response.ResponseMsg = "At least one field (Name, Unit, or IsActive) must be provided.";
                return response;
            }

            using var connection = _context.CreateConnection();
            connection.Open();

            try
            {
                var fetchParams = new DynamicParameters();
                fetchParams.Add("@IngredientId", model.IngredientId);
                fetchParams.Add("@Action", "SELECT");
                var existing = await connection.QueryFirstOrDefaultAsync<Ingredient>("sp_IngredientCRUD", fetchParams, commandType: CommandType.StoredProcedure);

                if (existing == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Ingredient not found.";
                    return response;
                }

                var parameters = new DynamicParameters();
                parameters.Add("@IngredientId", model.IngredientId);
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@Name", model.Name ?? existing.Name);
                parameters.Add("@Unit", model.Unit ?? existing.Unit);
                parameters.Add("@IsActive", model.IsActive ?? existing.IsActive);
                parameters.Add("@Price", existing.Price);
                parameters.Add("@UnitOfMeasure", existing.UnitOfMeasure);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@Action", "UPDATE");

                await connection.ExecuteAsync("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Ingredient details updated successfully.";
                response.Data = new { IngredientId = model.IngredientId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> DeleteIngredientAsync(int id, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@IngredientId", id);
                parameters.Add("@Userid", currentUserId);
                parameters.Add("@Action", "DELETE");

                var affectedRows = await connection.ExecuteAsync("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);
                if (affectedRows == 0)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Ingredient not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Ingredient deleted successfully.";
                response.Data = new { IngredientId = id };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> ToggleIngredientActiveAsync(int id, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@IngredientId", id);
                parameters.Add("@Action", "SELECT");

                var ingredient = await connection.QueryFirstOrDefaultAsync<Ingredient>("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (ingredient == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Ingredient not found.";
                    return response;
                }

                parameters = new DynamicParameters();
                parameters.Add("@IngredientId", id);
                parameters.Add("@Userid", currentUserId);
                parameters.Add("@IsActive", !ingredient.IsActive);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@Action", "TOGGLE_ACTIVE");

                await connection.ExecuteAsync("sp_IngredientCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = $"Ingredient {(ingredient.IsActive ? "deactivated" : "activated")} successfully.";
                response.Data = new { IngredientId = id, IsActive = !ingredient.IsActive };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllVendorsAsync(int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var vendors = await connection.QueryAsync<User>(@"
                    SELECT 
                        u.UserId, u.FirstName, u.LastName, u.Username, u.Email, u.Phone, 
                        u.ProfilePic, u.Address, u.Country, u.State, u.City, u.Zip, u.Gender,
                        u.RestaurantName, u.CuisineType, u.RestaurantSize, u.IsActive,
                        STRING_AGG(r.RoleName, ',') AS Roles,
                        u.CreatedOn, u.ModifiedOn,
                        CASE WHEN l.LinkedVendorId IS NOT NULL THEN 1 ELSE 0 END AS IsLinked
                    FROM Users u
                    INNER JOIN UserRoles ur ON u.UserId = ur.UserId
                    INNER JOIN Roles r ON ur.RoleId = r.RoleId
                    LEFT JOIN UserVendorIngredientsLinks l ON l.LinkedVendorId = u.UserId AND l.UserId = @UserId
                    WHERE r.RoleName = 'Vendor'
                    GROUP BY u.UserId, u.FirstName, u.LastName, u.Username, u.Email, u.Phone, u.ProfilePic, 
                        u.Address, u.Country, u.State, u.City, u.Zip, u.Gender, u.RestaurantName, 
                        u.CuisineType, u.RestaurantSize, u.IsActive, u.CreatedOn, u.ModifiedOn, l.LinkedVendorId",
                    new { UserId = currentUserId });

                response.Status = 200;
                response.ResponseMsg = "Vendors retrieved successfully.";
                response.Data = vendors;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> LinkVendorAsync(int vendorId, int currentUserId)
        {
            var response = new Response();

            try
            {
                using var connection = _context.CreateConnection();

                var existingLink = await connection.QueryFirstOrDefaultAsync<int>(
                    "SELECT 1 FROM UserVendorIngredientsLinks WHERE UserId = @UserId AND LinkedVendorId = @VendorId",
                    new { UserId = currentUserId, VendorId = vendorId });

                if (existingLink == 1)
                {
                    response.Status = 400;
                    response.ResponseMsg = "Vendor is already linked.";
                    return response;
                }

                await connection.ExecuteAsync(
                    @"INSERT INTO UserVendorIngredientsLinks (UserId, LinkedVendorId, CreatedBy, CreatedOn) 
                      VALUES (@UserId, @VendorId, @CreatedBy, GETDATE())",
                    new { UserId = currentUserId, VendorId = vendorId, CreatedBy = currentUserId });

                response.Status = 200;
                response.ResponseMsg = "Vendor linked successfully.";
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            return response;
        }

        public async Task<Response> UnlinkVendorAsync(int vendorId, int currentUserId)
        {
            var response = new Response();

            try
            {
                using var connection = _context.CreateConnection();

                var affectedRows = await connection.ExecuteAsync(
                    "DELETE FROM UserVendorIngredientsLinks WHERE UserId = @UserId AND LinkedVendorId = @VendorId",
                    new { UserId = currentUserId, VendorId = vendorId });

                if (affectedRows == 0)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Vendor link not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Vendor unlinked successfully.";
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            return response;
        }
    }
}
