using Dapper;
using Restaurant.Data;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class MenuEngineeringInsightsService : IMenuEngineeringInsightsService
    {
        private readonly DapperContext _context;

        public MenuEngineeringInsightsService(DapperContext context)
        {
            _context = context;
        }

        public async Task<Response> GetAllMenuEngineeringInsightsByUserIdAsync(int userId, DateTime? startDate, DateTime? endDate)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);
                parameters.Add("@UserId", userId);

                var insights = await connection.QueryAsync<MenuEngineeringInsights>("sp_GetMenuEngineeringInsightsByUserId", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Menu engineering insights retrieved successfully.";
                response.Data = insights;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
