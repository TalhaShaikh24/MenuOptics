using Dapper;
using Restaurant.Data;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class AnalyticsService : IAnalyticsService
    {
        private readonly DapperContext _context;

        public AnalyticsService(DapperContext context)
        {
            _context = context;
        }

        public async Task<Response> GetAnalyticsDashboardAsync(int userId, DateTime? startDate, DateTime? endDate)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", userId);
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);

                using var multi = await connection.QueryMultipleAsync("usp_GetRestaurantAnalytics", parameters, commandType: CommandType.StoredProcedure);

                var analytics = new AnalyticsDashboard();

                var revenueData = multi.ReadFirstOrDefault<(decimal? Current, decimal? Previous, decimal? Percentage)>();
                analytics.CurrentRevenue = revenueData.Current;
                analytics.PreviousRevenue = revenueData.Previous;
                analytics.PercentageChangeRevenue = revenueData.Percentage;

                var salesData = multi.ReadFirstOrDefault<(int? Current, int? Previous, decimal? Percentage)>();
                analytics.CurrentSalesCount = salesData.Current;
                analytics.PreviousSalesCount = salesData.Previous;
                analytics.PercentageChangeSales = salesData.Percentage;

                var avgOrderData = multi.ReadFirstOrDefault<(decimal? Current, decimal? Previous, decimal? Percentage)>();
                analytics.CurrentAvgOrderValue = avgOrderData.Current;
                analytics.PreviousAvgOrderValue = avgOrderData.Previous;
                analytics.PercentageChangeAvgOrder = avgOrderData.Percentage;

                var itemsSoldData = multi.ReadFirstOrDefault<(int? Current, int? Previous, decimal? Percentage)>();
                analytics.CurrentItemsSold = itemsSoldData.Current;
                analytics.PreviousItemsSold = itemsSoldData.Previous;
                analytics.PercentageChangeItems = itemsSoldData.Percentage;

                analytics.RevenueTrends = multi.Read<RevenueTrend>().ToList();
                analytics.RevenueDistribution = multi.Read<PieChartData>().ToList();
                analytics.MenuPerformances = multi.Read<MenuPerformance>().ToList();

                if (analytics.CurrentRevenue == null && analytics.CurrentSalesCount == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "No analytics data found for the specified user.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Analytics dashboard data retrieved successfully.";
                response.Data = analytics;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
