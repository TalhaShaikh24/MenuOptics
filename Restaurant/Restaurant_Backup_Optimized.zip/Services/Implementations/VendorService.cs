using Dapper;
using Microsoft.AspNetCore.Http;
using Restaurant.Data;
using Restaurant.Helpers;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class VendorService : IVendorService
    {
        private readonly DapperContext _context;
        private readonly IWebHostEnvironment _environment;

        public VendorService(DapperContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public async Task<Response> RegisterVendorAsync(User model, IFormFile? file, string scheme, string host)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var filePathUrl = "";
                if (file != null)
                {
                    var fileName = await FileUploadHelper.UploadFileAsync(file, _environment.WebRootPath, "Uploads");
                    filePathUrl = FileUploadHelper.GenerateFileUrl(fileName, scheme, host, "Uploads");
                }

                var parameters = new DynamicParameters();
                parameters.Add("@FirstName", model.FirstName);
                parameters.Add("@LastName", model.LastName);
                parameters.Add("@Username", model.Username);
                parameters.Add("@Email", model.Email);
                parameters.Add("@Phone", model.Phone);
                parameters.Add("@ProfilePic", filePathUrl);
                parameters.Add("@Address", model.Address);
                parameters.Add("@Country", model.Country);
                parameters.Add("@State", model.State);
                parameters.Add("@City", model.City);
                parameters.Add("@Zip", model.Zip);
                parameters.Add("@Gender", model.Gender);
                parameters.Add("@RestaurantName", model.RestaurantName);
                parameters.Add("@CuisineType", model.CuisineType);
                parameters.Add("@RestaurantSize", model.RestaurantSize);
                parameters.Add("@PasswordHash", BCrypt.Net.BCrypt.HashPassword(model.Password));
                parameters.Add("@RoleName", "Vendor");
                parameters.Add("@CreatedBy", model.CreatedBy ?? 1);
                parameters.Add("@IsActive", 0);
                parameters.Add("@Action", "INSERT");

                int userId = await connection.ExecuteScalarAsync<int>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "Vendor registered successfully. Awaiting admin approval.";
                response.Data = new { UserId = userId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
