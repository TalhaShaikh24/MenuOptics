using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Restaurant.Data;
using Restaurant.Helpers;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using System.Data;
using System.Text.Json;

namespace Restaurant.Services.Implementations
{
    public class MenuService : IMenuService
    {
        private readonly DapperContext _context;
        private readonly IWebHostEnvironment _env;

        public MenuService(DapperContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public async Task<Response> CreateMenuItemAsync(Menu model, string ingredientsJson, string recipesJson, IFormFile? file, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                if (!string.IsNullOrWhiteSpace(ingredientsJson))
                    model.Ingredients = JsonConvert.DeserializeObject<List<MenuItemIngredient>>(ingredientsJson);
                if (!string.IsNullOrWhiteSpace(recipesJson))
                    model.Recipes = JsonConvert.DeserializeObject<List<MenuItemRecipe>>(recipesJson);

                string featuredImagePath = null;

                if (file != null && file.Length > 0)
                {
                    var fileName = await FileUploadHelper.UploadFileAsync(file, _env.WebRootPath, "menu");
                    featuredImagePath = $"/menu/{fileName}";
                }

                var parameters = new DynamicParameters();
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@Name", model.Name);
                parameters.Add("@Description", model.Description);
                parameters.Add("@CategoryId", model.CategoryId);
                parameters.Add("@Cost", model.Cost);
                parameters.Add("@SellingPrice", model.SellingPrice);
                parameters.Add("@FeaturedImage", featuredImagePath);
                parameters.Add("@IsAvailable", model.IsAvailable);
                parameters.Add("@CreatedBy", currentUserId);
                parameters.Add("@Action", "INSERT");

                int menuItemId = await connection.ExecuteScalarAsync<int>("sp_MenuCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (model.Ingredients != null && model.Ingredients.Any())
                {
                    foreach (var ingredient in model.Ingredients)
                    {
                        var ingredientParams = new DynamicParameters();
                        ingredientParams.Add("@MenuItemId", menuItemId);
                        ingredientParams.Add("@IngredientId", ingredient.IngredientId);
                        ingredientParams.Add("@Quantity", ingredient.Quantity);
                        ingredientParams.Add("@Action", "INSERT");
                        await connection.ExecuteAsync("sp_MenuItemIngredientsCRUD", ingredientParams, commandType: CommandType.StoredProcedure);
                    }
                }

                if (model.Recipes != null && model.Recipes.Any())
                {
                    foreach (var recipe in model.Recipes)
                    {
                        var recipeParams = new DynamicParameters();
                        recipeParams.Add("@MenuItemId", menuItemId);
                        recipeParams.Add("@RecipeId", recipe.RecipeId);
                        recipeParams.Add("@Quantity", recipe.Quantity);
                        recipeParams.Add("@Action", "INSERT");
                        await connection.ExecuteAsync("sp_MenuItemRecipesCRUD", recipeParams, commandType: CommandType.StoredProcedure);
                    }
                }

                response.Status = 200;
                response.ResponseMsg = "Menu item created successfully.";
                response.Data = new { MenuItemId = menuItemId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetMenuItemAsync(int id)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@MenuItemId", id);
                parameters.Add("@Action", "SELECT");

                var menuItem = await connection.QueryFirstOrDefaultAsync<Menu>("sp_MenuCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (menuItem == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Menu item not found.";
                    return response;
                }

                var ingredientParams = new DynamicParameters();
                ingredientParams.Add("@MenuItemId", id);
                ingredientParams.Add("@Action", "SELECT_BY_MENU");
                var ingredients = await connection.QueryAsync<MenuItemIngredient>("sp_MenuItemIngredientsCRUD", ingredientParams, commandType: CommandType.StoredProcedure);

                var recipeParams = new DynamicParameters();
                recipeParams.Add("@MenuItemId", id);
                recipeParams.Add("@Action", "SELECT_BY_MENU");
                var recipesQuery = await connection.QueryAsync<MenuItemRecipe>("sp_MenuItemRecipesCRUD", recipeParams, commandType: CommandType.StoredProcedure);

                menuItem.Ingredients = ingredients.ToList();
                menuItem.Recipes = recipesQuery.ToList();

                response.Status = 200;
                response.ResponseMsg = "Menu item retrieved successfully.";
                response.Data = menuItem;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllMenuItemsByAdminAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL_ADMIN");

                var menuItems = await connection.QueryAsync<Menu, string, Menu>(
                    "sp_MenuCRUD",
                    (menu, ingredientsJson) =>
                    {
                        menu.Ingredients = !string.IsNullOrEmpty(ingredientsJson)
                            ? System.Text.Json.JsonSerializer.Deserialize<List<MenuItemIngredient>>(ingredientsJson)
                            : new List<MenuItemIngredient>();
                        return menu;
                    },
                    parameters,
                    splitOn: "Ingredients",
                    commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Menu items retrieved successfully.";
                response.Data = menuItems;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllMenuItemsAsync(int userId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", userId);
                parameters.Add("@Action", "SELECT_ALL");

                var menuItems = await connection.QueryAsync<Menu, string, string, Menu>(
                    "sp_MenuCRUD",
                    (menu, ingredientsJson, recipesJson) =>
                    {
                        menu.Ingredients = !string.IsNullOrEmpty(ingredientsJson)
                            ? System.Text.Json.JsonSerializer.Deserialize<List<MenuItemIngredient>>(ingredientsJson)
                            : new List<MenuItemIngredient>();
                        menu.Recipes = !string.IsNullOrEmpty(recipesJson)
                            ? System.Text.Json.JsonSerializer.Deserialize<List<MenuItemRecipe>>(recipesJson)
                            : new List<MenuItemRecipe>();
                        return menu;
                    },
                    parameters,
                    splitOn: "Ingredients,Recipes",
                    commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = "Menu items retrieved successfully.";
                response.Data = menuItems;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> UpdateMenuItemAsync(Menu model, string ingredientsJson, string recipesJson, IFormFile? file, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                if (model.MenuItemId <= 0)
                {
                    response.Status = 400;
                    response.ResponseMsg = "MenuItemId is required for updating a menu item.";
                    return response;
                }

                if (!string.IsNullOrWhiteSpace(ingredientsJson))
                    model.Ingredients = JsonConvert.DeserializeObject<List<MenuItemIngredient>>(ingredientsJson);
                if (!string.IsNullOrWhiteSpace(recipesJson))
                    model.Recipes = JsonConvert.DeserializeObject<List<MenuItemRecipe>>(recipesJson);

                string featuredImagePath = model.FeaturedImage;

                if (file != null && file.Length > 0)
                {
                    var fileName = await FileUploadHelper.UploadFileAsync(file, _env.WebRootPath, "menu");
                    featuredImagePath = $"/menu/{fileName}";
                }

                var parameters = new DynamicParameters();
                parameters.Add("@MenuItemId", model.MenuItemId);
                parameters.Add("@UserId", currentUserId);
                parameters.Add("@Name", model.Name);
                parameters.Add("@Description", model.Description);
                parameters.Add("@CategoryId", model.CategoryId);
                parameters.Add("@Cost", model.Cost);
                parameters.Add("@SellingPrice", model.SellingPrice);
                parameters.Add("@FeaturedImage", featuredImagePath);
                parameters.Add("@IsAvailable", model.IsAvailable);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@IsActive", true);
                parameters.Add("@IngredientsJson", ingredientsJson);
                parameters.Add("@RecipesJson", recipesJson);
                parameters.Add("@Action", "UPDATE");

                int affectedRows = await connection.ExecuteAsync("sp_MenuCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (affectedRows == 0)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Menu item not found or no changes were made.";
                    return response;
                }

                var deleteParams = new DynamicParameters();
                deleteParams.Add("@MenuItemId", model.MenuItemId);
                deleteParams.Add("@Action", "DELETE_ALL");
                await connection.ExecuteAsync("sp_MenuItemIngredientsCRUD", deleteParams, commandType: CommandType.StoredProcedure);

                var deleteRecipeParams = new DynamicParameters();
                deleteRecipeParams.Add("@MenuItemId", model.MenuItemId);
                deleteRecipeParams.Add("@Action", "DELETE_ALL");
                await connection.ExecuteAsync("sp_MenuItemRecipesCRUD", deleteRecipeParams, commandType: CommandType.StoredProcedure);

                if (model.Ingredients != null && model.Ingredients.Any())
                {
                    foreach (var ingredient in model.Ingredients)
                    {
                        var ingredientParams = new DynamicParameters();
                        ingredientParams.Add("@MenuItemId", model.MenuItemId);
                        ingredientParams.Add("@IngredientId", ingredient.IngredientId);
                        ingredientParams.Add("@Quantity", ingredient.Quantity);
                        ingredientParams.Add("@Action", "INSERT");
                        await connection.ExecuteAsync("sp_MenuItemIngredientsCRUD", ingredientParams, commandType: CommandType.StoredProcedure);
                    }
                }

                if (model.Recipes != null && model.Recipes.Any())
                {
                    foreach (var recipe in model.Recipes)
                    {
                        var recipeParams = new DynamicParameters();
                        recipeParams.Add("@MenuItemId", model.MenuItemId);
                        recipeParams.Add("@RecipeId", recipe.RecipeId);
                        recipeParams.Add("@Quantity", recipe.Quantity);
                        recipeParams.Add("@Action", "INSERT");
                        await connection.ExecuteAsync("sp_MenuItemRecipesCRUD", recipeParams, commandType: CommandType.StoredProcedure);
                    }
                }

                response.Status = 200;
                response.ResponseMsg = "Menu item updated successfully.";
                response.Data = new { MenuItemId = model.MenuItemId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> DeleteMenuItemAsync(int id)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@MenuItemId", id);
                parameters.Add("@Action", "DELETE");

                var affectedRows = await connection.ExecuteAsync("sp_MenuCRUD", parameters, commandType: CommandType.StoredProcedure);
                if (affectedRows == 0)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Menu item not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Menu item deleted successfully.";
                response.Data = new { MenuItemId = id };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> ToggleMenuActiveAsync(int id, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@MenuItemId", id);
                parameters.Add("@Action", "SELECT");

                var menuItem = await connection.QueryFirstOrDefaultAsync<Menu>("sp_MenuCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (menuItem == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "Menu item not found.";
                    return response;
                }

                parameters = new DynamicParameters();
                parameters.Add("@MenuItemId", id);
                parameters.Add("@IsActive", !menuItem.IsActive);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@Action", "TOGGLE_ACTIVE");

                await connection.ExecuteAsync("sp_MenuCRUD", parameters, commandType: CommandType.StoredProcedure);

                response.Status = 200;
                response.ResponseMsg = $"Menu Item {(menuItem.IsActive ? "deactivated" : "activated")} successfully.";
                response.Data = new { MenuItemId = id, IsActive = !menuItem.IsActive };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
