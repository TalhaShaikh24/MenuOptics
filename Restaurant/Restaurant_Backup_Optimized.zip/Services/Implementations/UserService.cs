using Dapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Restaurant.Data;
using Restaurant.Helpers;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using Stripe;
using Stripe.Checkout;
using System.Data;
using System.Security.Claims;

namespace Restaurant.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly DapperContext _context;
        private readonly IWebHostEnvironment _environment;
        private readonly IConfiguration _configuration;
        private readonly IActivityLogService _activityLog;
        private readonly ITokenService _tokenService;

        public UserService(DapperContext context, IWebHostEnvironment environment, IConfiguration configuration, IActivityLogService activityLog, ITokenService tokenService)
        {
            _context = context;
            _environment = environment;
            _configuration = configuration;
            _activityLog = activityLog;
            _tokenService = tokenService;
        }

        public async Task<Response> CreateUserAsync(User model, IFormFile? file, string scheme, string host, int? createdBy)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var filePathUrl = "";
                if (file != null)
                {
                    var fileName = await FileUploadHelper.UploadFileAsync(file, _environment.WebRootPath, "Uploads");
                    filePathUrl = FileUploadHelper.GenerateFileUrl(fileName, scheme, host, "Uploads");
                }

                var parameters = new DynamicParameters();
                parameters.Add("@FirstName", model.FirstName);
                parameters.Add("@LastName", model.LastName);
                parameters.Add("@Username", model.Username);
                parameters.Add("@Email", model.Email);
                parameters.Add("@Phone", model.Phone);
                parameters.Add("@ProfilePic", filePathUrl);
                parameters.Add("@Address", model.Address);
                parameters.Add("@Country", model.Country);
                parameters.Add("@State", model.State);
                parameters.Add("@City", model.City);
                parameters.Add("@Zip", model.Zip);
                parameters.Add("@Gender", model.Gender);
                parameters.Add("@RestaurantName", model.Role is "restaurant" or "Restaurant" or "admin" ? model.RestaurantName : null);
                parameters.Add("@CuisineType", model.Role is "restaurant" or "Restaurant" or "admin" ? model.CuisineType : null);
                parameters.Add("@RestaurantSize", model.Role is "restaurant" or "Restaurant" or "admin" ? model.RestaurantSize : null);
                parameters.Add("@PasswordHash", BCrypt.Net.BCrypt.HashPassword(model.Password));
                parameters.Add("@RoleName", model.Role);
                parameters.Add("@IsActive", model.IsActive);
                parameters.Add("@SubscriptionStatus", "Pending");
                parameters.Add("@CreatedBy", createdBy ?? 1);
                parameters.Add("@Action", "INSERT");

                int userId = await connection.ExecuteScalarAsync<int>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "User created successfully.";
                response.Data = new { UserId = userId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetUserAsync(int id)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", id);
                parameters.Add("@Action", "SELECT");

                var userProfile = await connection.QueryFirstOrDefaultAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (userProfile == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "User profile not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "User profile retrieved successfully.";
                response.Data = userProfile;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllUsersAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");

                var users = await connection.QueryAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "Users retrieved successfully.";
                response.Data = users;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetAllRestaurantsAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL_RESTAURANT");

                var users = await connection.QueryAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "Users retrieved successfully.";
                response.Data = users;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> UpdateUserAsync(User model, IFormFile? file, string scheme, string host)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                if (model.UserId <= 0)
                {
                    response.Status = 400;
                    response.ResponseMsg = "UserId is required for updating a user.";
                    return response;
                }

                var filePathUrl = model.ProfilePic;
                if (file != null)
                {
                    var fileName = await FileUploadHelper.UploadFileAsync(file, _environment.WebRootPath, "Uploads");
                    filePathUrl = FileUploadHelper.GenerateFileUrl(fileName, scheme, host, "Uploads");
                }

                var parameters = new DynamicParameters();
                parameters.Add("@UserId", model.UserId);
                parameters.Add("@FirstName", model.FirstName);
                parameters.Add("@LastName", model.LastName);
                parameters.Add("@Username", model.Username);
                parameters.Add("@Email", model.Email);
                parameters.Add("@Phone", model.Phone);
                parameters.Add("@ProfilePic", filePathUrl);
                parameters.Add("@Address", model.Address);
                parameters.Add("@Country", model.Country);
                parameters.Add("@State", model.State);
                parameters.Add("@City", model.City);
                parameters.Add("@Zip", model.Zip);
                parameters.Add("@Gender", model.Gender);
                parameters.Add("@RestaurantName", model.Role is "Restaurant" or "Customer" ? model.RestaurantName : null);
                parameters.Add("@CuisineType", model.Role is "Restaurant" or "Customer" ? model.CuisineType : null);
                parameters.Add("@RestaurantSize", model.Role is "Restaurant" or "Customer" ? model.RestaurantSize : null);
                parameters.Add("@RoleName", model.Role);
                parameters.Add("@IsActive", model.IsActive);
                parameters.Add("@ModifiedBy", model.ModifiedBy);
                parameters.Add("@Action", "UPDATE");

                int userId = await connection.ExecuteScalarAsync<int>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "User updated successfully.";
                response.Data = new { UserId = userId };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> ToggleUserActiveAsync(int id, int currentUserId)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", id);
                parameters.Add("@Action", "SELECT");
                var user = await connection.QueryFirstOrDefaultAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (user == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "User not found.";
                    return response;
                }

                parameters = new DynamicParameters();
                parameters.Add("@UserId", id);
                parameters.Add("@IsActive", !user.IsActive);
                parameters.Add("@ModifiedBy", currentUserId);
                parameters.Add("@Action", "TOGGLE_ACTIVE");

                await connection.ExecuteAsync("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = $"User {(user.IsActive ? "deactivated" : "activated")} successfully.";
                response.Data = new { UserId = id, IsActive = !user.IsActive };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> DeleteUserAsync(int id)
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", id);
                parameters.Add("@Action", "DELETE");

                var affectedRows = await connection.ExecuteAsync("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                if (affectedRows == 0)
                {
                    response.Status = 404;
                    response.ResponseMsg = "User not found.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "User deleted successfully.";
                response.Data = new { UserId = id };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> LoginAsync(LoginModel model, string requestId, HttpContext httpContext)
        {
            var response = new Response();
            var payload = System.Text.Json.JsonSerializer.Serialize(new { model.Username });

            using var connection = _context.CreateConnection();
            connection.Open();

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Username", model.Username);
                parameters.Add("@Action", "LOGIN");

                var user = await connection.QueryFirstOrDefaultAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (user == null)
                {
                    response.Status = 401;
                    response.ResponseMsg = "Invalid username.";
                    return response;
                }

                if (!BCrypt.Net.BCrypt.Verify(model.Password, user.PasswordHash))
                {
                    response.Status = 401;
                    response.ResponseMsg = "Invalid password.";
                    return response;
                }

                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.Username),
                    new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                    new Claim(ClaimTypes.Role, user.Roles),
                    new Claim("FirstName", user.FirstName ?? ""),
                    new Claim("LastName", user.LastName ?? "")
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddHours(1)
                };

                await httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

                var tokenString = _tokenService.GenerateAccessToken(user);
                var refreshTokenString = _tokenService.GenerateRefreshToken();
                await _tokenService.SaveRefreshTokenAsync(user.UserId, refreshTokenString);

                response.Status = 200;
                response.ResponseMsg = "Login successful.";
                response.Data = new
                {
                    UserId = user.UserId,
                    Roles = user.Roles,
                    ProfilePic = user.ProfilePic,
                    Token = tokenString,
                    RefreshToken = refreshTokenString
                };

                if (user.Roles?.Contains("Vendor") == true)
                {
                    await _activityLog.LogAsync(user.UserId, requestId, "POST /api/UserApi/Login", payload,
                        System.Text.Json.JsonSerializer.Serialize(new { response.Status, response.ResponseMsg }), "Success");
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower() == "invalidusername")
                {
                    response.Status = 401;
                    response.ResponseMsg = "Invalid Username";
                    return response;
                }

                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> LogoutAsync()
        {
            var response = new Response();
            response.Status = 200;
            response.ResponseMsg = "Logout successful.";
            return response;
        }

        public async Task<Response> GetUserStatsAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_USER_STATS");

                var stats = await connection.QueryFirstOrDefaultAsync<UserStats>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (stats == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "No user stats available.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "User stats retrieved successfully.";
                response.Data = stats;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> GetRestaurantStatsAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_RESTAURANT_STATS");

                var stats = await connection.QueryFirstOrDefaultAsync<UserStats>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (stats == null)
                {
                    response.Status = 404;
                    response.ResponseMsg = "No restaurant stats available.";
                    return response;
                }

                response.Status = 200;
                response.ResponseMsg = "Restaurant stats retrieved successfully.";
                response.Data = stats;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }

        public async Task<Response> RefreshTokenAsync(string refreshToken)
        {
            var response = new Response();

            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                response.Status = 400;
                response.ResponseMsg = "Refresh token is required.";
                return response;
            }

            try
            {
                var storedToken = await _tokenService.GetRefreshTokenAsync(refreshToken);

                if (storedToken == null)
                {
                    response.Status = 401;
                    response.ResponseMsg = "Invalid refresh token.";
                    return response;
                }

                if (storedToken.IsRevoked)
                {
                    response.Status = 401;
                    response.ResponseMsg = "Refresh token has been revoked.";
                    return response;
                }

                if (storedToken.ExpiresAt < DateTime.UtcNow)
                {
                    response.Status = 401;
                    response.ResponseMsg = "Refresh token has expired. Please log in again.";
                    return response;
                }

                using var connection = _context.CreateConnection();
                connection.Open();

                var parameters = new DynamicParameters();
                parameters.Add("@UserId", storedToken.UserId);
                parameters.Add("@Action", "SELECT");

                var user = await connection.QueryFirstOrDefaultAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);

                if (user == null || !user.IsActive)
                {
                    response.Status = 401;
                    response.ResponseMsg = "User not found or account is inactive.";
                    return response;
                }

                await _tokenService.RevokeRefreshTokenAsync(refreshToken);

                var newAccessToken = _tokenService.GenerateAccessToken(user);
                var newRefreshToken = _tokenService.GenerateRefreshToken();
                await _tokenService.SaveRefreshTokenAsync(user.UserId, newRefreshToken);

                response.Status = 200;
                response.ResponseMsg = "Token refreshed successfully.";
                response.Data = new
                {
                    Token = newAccessToken,
                    RefreshToken = newRefreshToken
                };
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            return response;
        }

        public async Task<Response> RevokeTokenAsync(string refreshToken)
        {
            var response = new Response();

            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                response.Status = 400;
                response.ResponseMsg = "Refresh token is required.";
                return response;
            }

            try
            {
                var storedToken = await _tokenService.GetRefreshTokenAsync(refreshToken);

                if (storedToken == null || storedToken.IsRevoked)
                {
                    response.Status = 400;
                    response.ResponseMsg = "Token is already invalid or does not exist.";
                    return response;
                }

                await _tokenService.RevokeRefreshTokenAsync(refreshToken);

                response.Status = 200;
                response.ResponseMsg = "Token revoked successfully.";
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            return response;
        }

        public object CreateCheckoutSession(string plan, int userId)
        {
            StripeConfiguration.ApiKey = _configuration["Stripe:SecretKey"];

            var priceId = plan switch
            {
                "starter" => _configuration["Stripe:StarterPriceId"],
                "professional" => _configuration["Stripe:ProfessionalPriceId"],
                _ => throw new Exception("Invalid plan")
            };

            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string> { "card" },
                Mode = "subscription",
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        Price = priceId,
                        Quantity = 1,
                    },
                },
                Metadata = new Dictionary<string, string>
                {
                    { "UserId", userId.ToString() }
                },
                SuccessUrl = $"{_configuration["Stripe:SuccessUrl"]}?session_id={{CHECKOUT_SESSION_ID}}&user_id={userId}",
                CancelUrl = _configuration["Stripe:CancelUrl"],
            };

            var service = new SessionService();
            var session = service.Create(options);

            return new { sessionId = session.Id };
        }
    }
}
