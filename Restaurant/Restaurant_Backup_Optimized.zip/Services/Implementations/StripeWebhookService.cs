using Dapper;
using Microsoft.AspNetCore.Http;
using Restaurant.Data;
using Restaurant.Models;
using Restaurant.Services.Interfaces;
using Stripe;
using System.Data;

namespace Restaurant.Services.Implementations
{
    public class StripeWebhookService : IStripeWebhookService
    {
        private readonly DapperContext _context;

        public StripeWebhookService(DapperContext context)
        {
            _context = context;
        }

        public async Task<Response> HandleWebhookAsync(string json, string signature)
        {
            var response = new Response();
            try
            {
                var stripeEvent = EventUtility.ConstructEvent(json, signature, "whsec_5faaa8f893e8ee04fe332d778da9a4b4807614c9f57791447440cfdcb58bca33");

                using var connection = _context.CreateConnection();
                connection.Open();
                try
                {
                    if (stripeEvent.Type == Events.CustomerSubscriptionUpdated || stripeEvent.Type == Events.CustomerSubscriptionDeleted)
                    {
                        var subscription = stripeEvent.Data.Object as Subscription;
                        var parameters = new DynamicParameters();
                        parameters.Add("@StripeSubscriptionId", subscription.Id);
                        parameters.Add("@SubscriptionStatus", subscription.Status == "active" ? "Active" : "Expired");
                        parameters.Add("@UserId", subscription.Status == "active" ? "Active" : "Expired");
                        parameters.Add("@Action", "UPDATE_SUBSCRIPTION");

                        await connection.ExecuteAsync("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                    }
                }
                finally
                {
                    connection.Close();
                }

                response.Status = 200;
            }
            catch (StripeException ex)
            {
                response.Status = 400;
                response.ResponseMsg = ex.Message;
            }
            return response;
        }

        public async Task<Response> GetAllUsersAsync()
        {
            var response = new Response();
            using var connection = _context.CreateConnection();
            connection.Open();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Action", "SELECT_ALL");

                var users = await connection.QueryAsync<UserDTO>("sp_UserCRUD", parameters, commandType: CommandType.StoredProcedure);
                response.Status = 200;
                response.ResponseMsg = "Users retrieved successfully.";
                response.Data = users;
            }
            catch (Exception ex)
            {
                response.Status = 500;
                response.ResponseMsg = $"Server error: {ex.Message}";
            }
            finally
            {
                connection.Close();
            }
            return response;
        }
    }
}
