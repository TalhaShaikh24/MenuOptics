using Dapper;
using Restaurant.Data;
using Restaurant.Models;
using Restaurant.Services.Interfaces;

namespace Restaurant.Services.Implementations
{
    public class EventOnlyItemService : IEventOnlyItemService
    {
        private readonly DapperContext _context;

        public EventOnlyItemService(DapperContext context)
        {
            _context = context;
        }

        public async Task<object> GetAllAsync(int restaurantId)
        {
            using var connection = _context.CreateConnection();
            var items = await connection.QueryAsync<EventOnlyItemDTO>(
                "sp_EventOnlyItemCRUD",
                new { Action = "SELECT_ALL", RestaurantId = restaurantId },
                commandType: System.Data.CommandType.StoredProcedure
            );
            return new { data = items };
        }

        public async Task<object> CreateAsync(string name, decimal defaultCost, int restaurantId)
        {
            using var connection = _context.CreateConnection();
            var newId = await connection.ExecuteScalarAsync<int>(
                "sp_EventOnlyItemCRUD",
                new { Action = "INSERT", RestaurantId = restaurantId, Name = name, DefaultCost = defaultCost },
                commandType: System.Data.CommandType.StoredProcedure
            );
            return new { status = 200, data = new { EventOnlyItemId = newId, Name = name, DefaultCost = defaultCost } };
        }
    }
}
