using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IPolicyService
    {
        Task<Response> GetAllPoliciesAsync();
        Task<Response> GetPolicyByTypeAsync(string type);
        Task<Response> SavePolicyAsync(PolicyDTO model, int currentUserId);
    }
}
