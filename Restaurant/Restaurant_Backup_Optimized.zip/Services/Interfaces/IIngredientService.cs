using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IIngredientService
    {
        Task<Response> CreateIngredientByVendorAsync(VendorIngredientRequest model, int currentUserId, string requestId);
        Task<Response> UpdateIngredientPricesAsync(UpdateIngredientPriceRequest model, int currentUserId, string requestId);
        Task<Response> CreateIngredientAsync(Ingredient model, int currentUserId);
        Task<Response> AddIngredientStockAsync(Inventory model, int currentUserId);
        Task<Response> GetIngredientAsync(int id);
        Task<Response> GetAllIngredientsAsync();
        Task<Response> GetAllIngredientsByUserIdAsync(int userId);
        Task<Response> GetAllIngredientsByVendorIdAsync(int vendorId);
        Task<Response> GetAllIngredientsByUserIdParamAsync(int userId);
        Task<Response> UpdateIngredientAsync(Ingredient model, int currentUserId);
        Task<Response> PatchIngredientDetailsAsync(UpdateIngredientDetailsRequest model, int currentUserId);
        Task<Response> DeleteIngredientAsync(int id, int currentUserId);
        Task<Response> ToggleIngredientActiveAsync(int id, int currentUserId);
        Task<Response> GetAllVendorsAsync(int currentUserId);
        Task<Response> LinkVendorAsync(int vendorId, int currentUserId);
        Task<Response> UnlinkVendorAsync(int vendorId, int currentUserId);
    }
}
