using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IRecipeService
    {
        Task<Response> CreateRecipeAsync(Recipe model, string ingredientsJson, int currentUserId);
        Task<Response> UpdateRecipeAsync(Recipe model, string ingredientsJson, int currentUserId);
        Task<Response> GetRecipeAsync(int id);
        Task<Response> GetAllRecipesAsync(int userId);
        Task<Response> DeleteRecipeAsync(int id, int currentUserId);
        Task<Response> ToggleRecipeActiveAsync(int id, int currentUserId);
    }
}
