using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IUserService
    {
        Task<Response> CreateUserAsync(User model, IFormFile? file, string scheme, string host, int? createdBy);
        Task<Response> GetUserAsync(int id);
        Task<Response> GetAllUsersAsync();
        Task<Response> GetAllRestaurantsAsync();
        Task<Response> UpdateUserAsync(User model, IFormFile? file, string scheme, string host);
        Task<Response> ToggleUserActiveAsync(int id, int currentUserId);
        Task<Response> DeleteUserAsync(int id);
        Task<Response> LoginAsync(LoginModel model, string requestId, HttpContext httpContext);
        Task<Response> LogoutAsync();
        Task<Response> GetUserStatsAsync();
        Task<Response> GetRestaurantStatsAsync();
        Task<Response> RefreshTokenAsync(string refreshToken);
        Task<Response> RevokeTokenAsync(string refreshToken);
        object CreateCheckoutSession(string plan, int userId);
    }
}
