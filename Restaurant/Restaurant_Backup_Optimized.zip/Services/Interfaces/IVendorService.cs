using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IVendorService
    {
        Task<Response> RegisterVendorAsync(User model, IFormFile? file, string scheme, string host);
    }
}
