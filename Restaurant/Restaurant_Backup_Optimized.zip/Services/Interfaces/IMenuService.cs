using Microsoft.AspNetCore.Http;
using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IMenuService
    {
        Task<Response> CreateMenuItemAsync(Menu model, string ingredientsJson, string recipesJson, IFormFile? file, int currentUserId);
        Task<Response> GetMenuItemAsync(int id);
        Task<Response> GetAllMenuItemsByAdminAsync();
        Task<Response> GetAllMenuItemsAsync(int userId);
        Task<Response> UpdateMenuItemAsync(Menu model, string ingredientsJson, string recipesJson, IFormFile? file, int currentUserId);
        Task<Response> DeleteMenuItemAsync(int id);
        Task<Response> ToggleMenuActiveAsync(int id, int currentUserId);
    }
}
