using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IEventOnlyItemService
    {
        Task<object> GetAllAsync(int restaurantId);
        Task<object> CreateAsync(string name, decimal defaultCost, int restaurantId);
    }
}
