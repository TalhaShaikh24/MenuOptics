using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface ICategoryService
    {
        Task<Response> GetAllCategoriesAsync(int restaurantId);
        Task<Response> GetCategoryAsync(int id, int restaurantId);
        Task<Response> CreateCategoryAsync(string name, string? description, int createdBy);
        Task<Response> UpdateCategoryAsync(int categoryId, string name, string? description, bool isActive, int modifiedBy);
        Task<Response> ToggleCategoryActiveAsync(int id, int modifiedBy);
        Task<Response> DeleteCategoryAsync(int id, int modifiedBy);
    }
}
