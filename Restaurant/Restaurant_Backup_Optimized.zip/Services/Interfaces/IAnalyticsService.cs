using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IAnalyticsService
    {
        Task<Response> GetAnalyticsDashboardAsync(int userId, DateTime? startDate, DateTime? endDate);
    }
}
