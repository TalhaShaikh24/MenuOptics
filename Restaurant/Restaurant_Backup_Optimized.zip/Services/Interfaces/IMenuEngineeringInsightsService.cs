using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IMenuEngineeringInsightsService
    {
        Task<Response> GetAllMenuEngineeringInsightsByUserIdAsync(int userId, DateTime? startDate, DateTime? endDate);
    }
}
