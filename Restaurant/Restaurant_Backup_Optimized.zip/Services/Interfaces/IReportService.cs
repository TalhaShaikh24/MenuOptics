using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IReportService
    {
        Task<Response> CogsReportAsync(CogsReportRequest model, int currentUserId);
    }
}
