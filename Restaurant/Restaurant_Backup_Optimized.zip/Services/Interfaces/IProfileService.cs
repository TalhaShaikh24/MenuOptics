using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IProfileService
    {
        Task<Response> GetCurrentUserAsync(int userId);
        Task<object> UpdateProfileAsync(User model, IFormFile? file, string scheme, string host, int currentUserId);
    }
}
