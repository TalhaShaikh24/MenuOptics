using Restaurant.Models;

namespace Restaurant.Services.Interfaces
{
    public interface IStripeWebhookService
    {
        Task<Response> HandleWebhookAsync(string json, string signature);
        Task<Response> GetAllUsersAsync();
    }
}
