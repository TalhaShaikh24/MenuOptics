CREATE PROCEDURE sp_GetIngredientPriceForRecipe
    @IngredientId INT,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT COALESCE(vip.Price, i.Price) AS Price
    FROM Ingredients i
    LEFT JOIN VendorIngredientRestaurantPrices vip
        ON i.IngredientId = vip.VendorIngredientId AND vip.RestaurantId = @UserId
    WHERE i.IngredientId = @IngredientId;
END;
GO

CREATE PROCEDURE sp_GetRecipeIngredientsByRecipeId
    @RecipeId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT ri.RecipeId, ri.IngredientId, i.Name AS IngredientName, ri.Quantity, ri.Unit
    FROM RecipeIngredients ri
    INNER JOIN Ingredients i ON i.IngredientId = ri.IngredientId
    WHERE ri.RecipeId = @RecipeId;
END;
GO
