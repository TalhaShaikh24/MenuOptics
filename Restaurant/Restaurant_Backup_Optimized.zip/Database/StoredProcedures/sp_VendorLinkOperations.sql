CREATE PROCEDURE sp_GetAllVendorsByRestaurant
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        u.UserId, u.FirstName, u.LastName, u.Username, u.Email, u.Phone, 
        u.ProfilePic, u.Address, u.Country, u.State, u.City, u.Zip, u.Gender,
        u.RestaurantName, u.CuisineType, u.RestaurantSize, u.IsActive,
        STRING_AGG(r.RoleName, ',') AS Roles,
        u.CreatedOn, u.ModifiedOn,
        CASE WHEN l.LinkedVendorId IS NOT NULL THEN 1 ELSE 0 END AS IsLinked
    FROM Users u
    INNER JOIN UserRoles ur ON u.UserId = ur.UserId
    INNER JOIN Roles r ON ur.RoleId = r.RoleId
    LEFT JOIN UserVendorIngredientsLinks l 
        ON l.LinkedVendorId = u.UserId AND l.UserId = @UserId
    WHERE r.RoleName = 'Vendor'
    GROUP BY 
        u.UserId, u.FirstName, u.LastName, u.Username, u.Email, u.Phone, u.ProfilePic, 
        u.Address, u.Country, u.State, u.City, u.Zip, u.Gender, u.RestaurantName, 
        u.CuisineType, u.RestaurantSize, u.IsActive, u.CreatedOn, u.ModifiedOn, 
        l.LinkedVendorId;
END;
GO

CREATE PROCEDURE sp_CheckVendorLinkExists
    @UserId INT,
    @VendorId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 1 FROM UserVendorIngredientsLinks 
    WHERE UserId = @UserId AND LinkedVendorId = @VendorId;
END;
GO

CREATE PROCEDURE sp_LinkVendorToRestaurant
    @UserId INT,
    @VendorId INT,
    @CreatedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO UserVendorIngredientsLinks (UserId, LinkedVendorId, CreatedBy, CreatedOn)
    VALUES (@UserId, @VendorId, @CreatedBy, GETDATE());
END;
GO

CREATE PROCEDURE sp_UnlinkVendorFromRestaurant
    @UserId INT,
    @VendorId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM UserVendorIngredientsLinks 
    WHERE UserId = @UserId AND LinkedVendorId = @VendorId;
END;
GO

CREATE PROCEDURE sp_DeleteEventItemsByEventId
    @EventId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM EventItems WHERE EventId = @EventId;
END;
GO
