CREATE PROCEDURE sp_MenuItemIngredientsCRUD
    @MenuItemId INT = NULL,
    @IngredientId INT = NULL,
    @Quantity DECIMAL(18,2) = NULL,
    @Action VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    IF @Action = 'INSERT'
    BEGIN
        INSERT INTO MenuItemIngredients (MenuItemId, IngredientId, Quantity)
        VALUES (@MenuItemId, @IngredientId, @Quantity);
        SELECT SCOPE_IDENTITY();
    END
    ELSE IF @Action = 'SELECT_BY_MENU'
    BEGIN
        SELECT mi.MenuItemId, mi.IngredientId, i.Name AS IngredientName, mi.Quantity, i.Unit
        FROM MenuItemIngredients mi
        INNER JOIN Ingredients i ON i.IngredientId = mi.IngredientId
        WHERE mi.MenuItemId = @MenuItemId;
    END
    ELSE IF @Action = 'DELETE_ALL'
    BEGIN
        DELETE FROM MenuItemIngredients WHERE MenuItemId = @MenuItemId;
    END
END;
GO
