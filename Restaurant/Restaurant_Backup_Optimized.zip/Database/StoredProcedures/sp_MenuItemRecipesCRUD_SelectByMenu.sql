CREATE PROCEDURE sp_MenuItemRecipesCRUD
    @MenuItemId INT = NULL,
    @RecipeId INT = NULL,
    @Quantity DECIMAL(18,2) = NULL,
    @Action VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    IF @Action = 'INSERT'
    BEGIN
        INSERT INTO MenuItemRecipes (MenuItemId, RecipeId, Quantity)
        VALUES (@MenuItemId, @RecipeId, @Quantity);
        SELECT SCOPE_IDENTITY();
    END
    ELSE IF @Action = 'SELECT_BY_MENU'
    BEGIN
        SELECT mr.MenuItemId, mr.RecipeId, r.Name AS RecipeName, mr.Quantity, r.Unit
        FROM MenuItemRecipes mr
        INNER JOIN Recipes r ON r.RecipeId = mr.RecipeId
        WHERE mr.MenuItemId = @MenuItemId;
    END
    ELSE IF @Action = 'DELETE_ALL'
    BEGIN
        DELETE FROM MenuItemRecipes WHERE MenuItemId = @MenuItemId;
    END
END;
GO
