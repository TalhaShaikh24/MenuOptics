﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Filters;

namespace Restaurant.Controllers
{
    public class MenuEngineeringInsightsController : Controller
    {
        [AuthorizeAdmin]
        public IActionResult Index()
        {
            return View();
        }
    }
}
