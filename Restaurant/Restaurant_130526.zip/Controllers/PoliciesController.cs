﻿using Microsoft.AspNetCore.Mvc;

namespace Restaurant.Controllers
{
    public class PoliciesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
