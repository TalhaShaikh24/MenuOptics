﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Filters;

namespace Restaurant.Controllers
{
    public class SalesController : Controller
    {
        
        [AuthorizeAdmin]
        public IActionResult Index()
        {
            return View();
        }
    }
}
