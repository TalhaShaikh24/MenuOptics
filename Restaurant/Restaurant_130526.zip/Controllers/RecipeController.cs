﻿using Microsoft.AspNetCore.Mvc;

namespace Restaurant.Controllers
{
    public class RecipeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
