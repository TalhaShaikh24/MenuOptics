﻿using Microsoft.AspNetCore.Mvc;

namespace Restaurant.Controllers
{
    public class InventoryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
