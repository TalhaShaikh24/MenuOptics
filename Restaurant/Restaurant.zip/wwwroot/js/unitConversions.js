﻿// Unit Conversion Utility Functions
// Supports: g, kg, lbs, oz, ml, l, pcs

const CONVERSION_RATES = {
    // Weight conversions (base unit: grams)
    weight: {
        'g': 1,
        'kg': 1000,
        'lbs': 453.59237,
        'oz': 28.349523125
    },
    // Volume conversions (base unit: milliliters)
    volume: {
        'ml': 1,
        'l': 1000
    },
    // Piece (no conversion needed)
    piece: {
        'pcs': 1
    }
};

// Determine the category of a unit
function getUnitCategory(unit) {
    if (['g', 'kg', 'lbs', 'oz'].includes(unit)) return 'weight';
    if (['ml', 'l'].includes(unit)) return 'volume';
    if (['pcs'].includes(unit)) return 'piece';
    return null;
}

// Convert quantity from one unit to another
function convertUnit(quantity, fromUnit, toUnit) {
    // If units are the same, no conversion needed
    if (fromUnit === toUnit) {
        return quantity;
    }

    const fromCategory = getUnitCategory(fromUnit);
    const toCategory = getUnitCategory(toUnit);

    // Can't convert between different categories (e.g., weight to volume)
    if (fromCategory !== toCategory || !fromCategory) {
        console.warn(`Cannot convert from ${fromUnit} to ${toUnit} - different categories`);
        return quantity;
    }

    // Get conversion rates
    const conversionTable = CONVERSION_RATES[fromCategory];

    // Convert to base unit first, then to target unit
    const baseQuantity = quantity * conversionTable[fromUnit];
    const convertedQuantity = baseQuantity / conversionTable[toUnit];

    return convertedQuantity;
}

// Get all possible units for conversion based on current unit
function getCompatibleUnits(unit) {
    const category = getUnitCategory(unit);
    if (!category) return [unit];

    return Object.keys(CONVERSION_RATES[category]);
}

// Format unit display with unitOfMeasure
function formatUnitDisplay(unit, unitOfMeasure) {
    if (unitOfMeasure && unitOfMeasure !== unit) {
        return `${unitOfMeasure} (${unit})`;
    }
    return unit;
}

// Calculate ingredient cost with unit conversion
function calculateIngredientCost(ingredientPrice, ingredientUnit, recipeQuantity, recipeUnit) {
    // Convert recipe quantity to ingredient unit
    const convertedQuantity = convertUnit(recipeQuantity, recipeUnit, ingredientUnit);
    return ingredientPrice * convertedQuantity;
}

// Get unit conversion info for display
function getConversionInfo(fromUnit) {
    const category = getUnitCategory(fromUnit);
    if (!category) return {};

    const conversions = {};
    const compatibleUnits = getCompatibleUnits(fromUnit);

    compatibleUnits.forEach(toUnit => {
        if (toUnit !== fromUnit) {
            const converted = convertUnit(1, fromUnit, toUnit);
            conversions[toUnit] = converted;
        }
    });

    return conversions;
}

// Example usage:
// convertUnit(1, 'kg', 'g') => 1000
// convertUnit(1, 'kg', 'lbs') => 2.2046226218
// convertUnit(1, 'l', 'ml') => 1000
// getCompatibleUnits('kg') => ['g', 'kg', 'lbs', 'oz']
// calculateIngredientCost(10, 'kg', 500, 'g') => 5 (10 * 0.5)