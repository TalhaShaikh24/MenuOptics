﻿$(document).ready(function () {

    // ──────────────────────────────────────────────────────────────
    // Helpers: show/hide steps
    // ──────────────────────────────────────────────────────────────
    function showStep(stepId) {
        $('#step-email, #step-password, #step-setup').hide();
        $('#' + stepId).show();
    }

    function resetToEmail() {
        $('#loginIdentifier').val('');
        $('#password').val('');
        $('#resolvedUsername').val('');
        $('#setupUserId').val('');
        $('#setupFirstName').val('');
        $('#setupLastName').val('');
        $('#setupPassword').val('');
        $('#setupPasswordConfirm').val('');
        $('#setupProfilePic').val('');
        showStep('step-email');
    }

    // ──────────────────────────────────────────────────────────────
    // STEP 1 — Check Email
    // ──────────────────────────────────────────────────────────────
    $('#checkEmailBtn').on('click', function () {
        var identifier = $.trim($('#loginIdentifier').val());

        
        ajaxRequest({
            url: '/api/UserApi/CheckEmail',
            method: 'POST',
            data: { Email: identifier },   // @Email param accepts email OR username
            showMessage: false,
            onSuccess: function (response) {
                var data = response.data;

                if (data.isRegistrationCompleted) {
                    // ── Registration already completed → show password step
                    $('#confirmedIdentifier').val(identifier);
                    // SP returns the actual Username — use it for the Login call
                    $('#resolvedUsername').val(data.username || identifier);
                    showStep('step-password');
                } else {
                    // ── First-time member → show account setup step
                    $('#setupUserId').val(data.userId);
                    showStep('step-setup');
                }
            }
        });
    });

    // Allow pressing Enter on the identifier field
    $('#loginIdentifier').on('keydown', function (e) {
        if (e.key === 'Enter') $('#checkEmailBtn').trigger('click');
    });

    // ──────────────────────────────────────────────────────────────
    // "Back" buttons
    // ──────────────────────────────────────────────────────────────
    $('#backToEmailBtn, #backToEmailBtnSetup').on('click', resetToEmail);

    // ──────────────────────────────────────────────────────────────
    // STEP 2a — Normal Login (IsRegistrationCompleted = 1)
    // Uses the existing /api/UserApi/Login endpoint unchanged.
    // ──────────────────────────────────────────────────────────────
    $('#loginFormBtn').on('click', function () {
        var username = $.trim($('#resolvedUsername').val());
        var password = $('#password').val();

      
        var formData = {
            Username: username,
            Password: password
        };

        ajaxRequest({
            url: '/api/UserApi/Login',
            method: 'POST',
            data: formData,
            showMessage: true,
            onSuccess: function (response) {
                Cookies.set('JwtToken', response.data.token);
                localStorage.setItem('profilePic', response.data.profilePic);

                var redirectUrl = response.data.roles.includes('Admin')
                    ? '/User/Index'
                    : '/Menu/Index';

                setTimeout(function () {
                    window.location.href = redirectUrl;
                }, 2000);
            },
            onError: function (xhr, status, error) {
                console.error('Login failed:', error);
            }
        });
    });

    // Allow pressing Enter on the password field
    $('#password').on('keydown', function (e) {
        if (e.key === 'Enter') $('#loginFormBtn').trigger('click');
    });

    // ──────────────────────────────────────────────────────────────
    // STEP 2b — Complete Registration (IsRegistrationCompleted = 0)
    // ──────────────────────────────────────────────────────────────
    $('#completeSetupBtn').on('click', function () {
        var userId = $('#setupUserId').val();
        var firstName = $.trim($('#setupFirstName').val());
        var lastName = $.trim($('#setupLastName').val());
        var password = $('#setupPassword').val();
        var confirm = $('#setupPasswordConfirm').val();
        var picFile = $('#setupProfilePic')[0].files[0];

      

        // Build multipart/form-data (required for file upload)
        var formData = new FormData();
        formData.append('UserId', userId);
        formData.append('FirstName', firstName);
        formData.append('LastName', lastName);
        formData.append('Password', password);
        if (picFile) {
            formData.append('File', picFile);
        }

        // completeSetupBtn loading state
        var $btn = $('#completeSetupBtn');
        $btn.find('.btn-text').hide();
        $btn.find('.btn-loading').show();
        $btn.prop('disabled', true);

        $.ajax({
            url: '/api/UserApi/CompleteRegistration',
            method: 'POST',
            data: formData,
            processData: false,   // do NOT let jQuery serialize FormData
            contentType: false,   // let the browser set multipart boundary
            success: function (response) {
                Cookies.set('JwtToken', response.data.token);
                localStorage.setItem('profilePic', response.data.profilePic);


                var redirectUrl = (response.data.roles && response.data.roles.includes('Admin'))
                    ? '/User/Index'
                    : '/Menu/Index';

                setTimeout(function () {
                    window.location.href = redirectUrl;
                }, 2000);
            },
            error: function (xhr) {

                $btn.find('.btn-text').show();
                $btn.find('.btn-loading').hide();
                $btn.prop('disabled', false);
            }
        });
    });

  

    // ──────────────────────────────────────────────────────────────
    // Forgot Password
    // Delegates to whatever forgot-password route exists in the project.
    // Update the href/action below to match your implementation.
    // ──────────────────────────────────────────────────────────────
    $('#forgotPasswordLink').on('click', function (e) {
        e.preventDefault();
        window.location.href = '/User/ForgotPassword';
    });


});